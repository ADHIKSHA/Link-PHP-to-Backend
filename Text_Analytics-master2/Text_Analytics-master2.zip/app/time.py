import time
t=time.time()
print(int(t))
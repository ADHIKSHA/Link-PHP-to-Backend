This is documentation for how to use this app.
1) cd into the folder Text_Analytics-master
3) write command -> pip install -r requirements.txt
2)write the command -> python manage.py runserver
3) Add this folder the script "calling.php" to your Php server(htdocs for XAMPP).
4) Check if the app is running properly.
5) You should get the correct output.
6) the parameters are passed from the php script to the python backend.
7) We can change the url in the php script if you host the app on cloud.